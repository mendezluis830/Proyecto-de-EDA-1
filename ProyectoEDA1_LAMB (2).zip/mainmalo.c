
#include <stdio.h>
#include <stdlib.h>
#include "Inventario.h"
#include "Administracion.h"


int main(int argc, char** argv)//luis se la come 
//
{
	const char *iduser;
	int w,d,v=0,g;
	printf("°°°°°°°°°°°°°°°°°°°°°°°°°LIBRERIAS SCHOPENHAUER°°°°°°°°°°°°°°°°°°°°°°°°°​");
	printf("\nBienvenido a nuestra libreria en linea ");
	printf("\nPor favor ingrese la operacion que desea realizar");
	printf("\n1)Mostrar listado de libros\n2)Buscar libro por titulo \n3)Buscar libro por medio del nombre del autor");
	printf("\n4)Buscar libro por medio del ISBN\n");
	printf(" \n5)Administrador ");
	scanf("%d",&w);

	switch (w)
	{
			case (1):		
						printf("Por favor copie el ISBN de los libros que sean de su interes para posteriormente agregarlos al carrito");
						do{ 
							ListarInventario();
							printf("¿Desea ver el inventario de nuevo? 0 = si , 1 = no ");
							scanf("%d",v);}while (v==0);			
				break;

			case (2):	printf("Por favor copie el ISBN de los libros que sean de su interes para posteriormente agregarlos al carrito");	
						do{		BuscarLibroPorTitulo();
								printf("¿Desea ver el buscar otro libro? 0 = si , 1 = no ");
								scanf("%d",v);		}while (v==0);

				break;

			case (3):		
						printf("Por favor copie el ISBN de los libros que sean de su interes para posteriormente agregarlos al carrito");
						do	{BuscarLibroPorAutor();
							printf("¿Desea ver el buscar otro libro? 0 = si , 1 = no ");
								scanf("%d",v);		}while (v==0);
				break;

			case (4):	printf("Por favor copie el ISBN de los libros que sean de su interes para posteriormente agregarlos al carrito");	
						do{		BuscarLibroPorISBN();
						printf("¿Desea ver el buscar otro libro? 0 = si , 1 = no ");
								scanf("%d",v);		}while (v==0);

				break;

			case (5):	printf("1)Agregar libro al inventario\n2)Dar de baja un libro\n3)Agregar existencias");
						printf("\nNumero de operacion");
						scanf("%d",d);
						if(d>1){
							if(d>2){
								void AgregarExistenciasLibro();
							}
							else {void BajaLibro();}
						}
						else {void AltaLibro();}
				exit;

			default:	printf("por favor introduzca una opcion valida");
			break;
	}
		printf("Agrege sus elecciones de compra al carrito usando ISBN\n");
				List *caja,*carrito;
				Data *libroporagregar;
				carrito = createStack();
		do	{
				printf("\n");
				scanf("%s",&iduser);
				caja = Buscar(ISBN,iduser);
				libroporagregar = peek(caja);
				void push(carrito,libroporagregar);
				void mostrarLibro(libroporagregar);	
				void DisminuirExistenciasLibro(iduser);
				printf("Desea agregar uno mas? si = 0 no = 1;");	}while (g==0);
		//bro segun yo aqui se crea la pila y se imprime el nombre de el libro adquirido 
		//y se dismunuye su existencia 
		printf("ver carrito de compra y total compra");
		void traverse(carrito);
		














	//LeerArchivoBD("D:\\Documents\\Luis\\ProyectoEDA1_Luis\\ProyectoEDA1_Luis\\InventarioLibros.txt");
	//ListarInventario();
	//AltaLibro();
	//BajaLibro();
	//AgregarExistenciasLibro();
	//ListarInventario();
	//BuscarLibroPorAutor();
	//GuardarArchivoBD("D:\\Documents\\Luis\\ProyectoEDA1_Luis\\ProyectoEDA1_Luis\\InventarioLibros.txt");
	return 0;
}
